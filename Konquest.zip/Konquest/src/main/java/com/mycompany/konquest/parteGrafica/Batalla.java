/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.konquest.parteGrafica;

import com.mycompany.konquest.planetas.*;
import javax.swing.JOptionPane;

/**
 *
 * @author DELL
 */
public class Batalla extends javax.swing.JFrame {

    protected Player_1 Player_1;
    protected Player_2 Player_2;
    protected Neutral_A Neutral_A;
    protected Neutral_B Neutral_B;
    protected Neutral_C Neutral_C;
    protected Neutral_D Neutral_D;
    protected Neutral_E Neutral_E;
    protected Neutral_F Neutral_F;
    protected Neutral_G Neutral_G;
    protected Neutral_H Neutral_H;
    protected Neutral_I Neutral_I;
    protected Neutral_J Neutral_J;
    protected Zombie_A Zombie_A;
    protected Zombie_B Zombie_B;
    protected Zombie_C Zombie_C;
    protected Zombie_D Zombie_D;
    protected Zombie_E Zombie_E;
    protected Zombie_F Zombie_F;
    protected Zombie_G Zombie_G;
    protected Zombie_H Zombie_H;
    protected Zombie_I Zombie_I;
    protected Zombie_J Zombie_J;
    protected boolean ciego;
    protected boolean produccion;
    protected boolean distribuir;
    protected boolean naves;
    protected boolean atributos;
    protected int anchura;
    protected int altura;
    protected int turnos;
    protected int neutrales;
    protected int zombies;
    protected String nombre;
    protected String mapa[][] = new String[6][8];
    
    // Arreglos del Jugador 1
    protected String planetasDelJU[] = new String[10];
    protected int turnosAtaquesJugadorUno[] = new int[10];
    protected String planetasQueAtacanJU[] = new String[10];
    protected String planetasAAtacarJU[] = new String[10]; 
    protected int numeroDeTropasJUA[] = new int[10];
    protected int turnosRefuerzosJugadorUno[] = new int[10];
    protected String planetasAReforzarJU[] = new String[10];
    protected int numeroDeTropasJUR[] = new int[10];
    
    // Arreglos del Jugador 2
    protected String planetasDelJD[] = new String[10];
    protected int turnosAtaquesJugadorDos[] = new int[10];
    protected String planetasQueAtacanJD[] = new String[10];
    protected String planetasAAtacarJD[] = new String[10]; 
    protected int numeroDeTropasJDA[] = new int[10];
    protected int turnosRefuerzosJugadorDos[] = new int[10];
    protected String planetasAReforzarJD[] = new String[10];
    protected int numeroDeTropasJDR[] = new int[10];
    
    // Controles
    protected String emisor;
    protected int coordenada = 0;
    protected int jugadorEnTurno = 1;
    protected String planetaEmisor = null;
    protected int filaInicio = 0; protected int columnaInicio = 0; protected int filaFinal = 0; protected int columnaFinal = 0;
    protected int abrir = 0;
    protected int turno = 1;
    protected int naves1 = 0;
    protected double porcentaje1 = 0;
    protected int naves2 = 0;
    protected double porcentaje2 = 0;
    protected int acceso = 0;
 
    /**
     * Creates new form Batalla
     */
    public Batalla(boolean ciego,boolean produccion,boolean distribuir,boolean naves,boolean atributos,int anchura,int altura,int turnos,int neutrales,int zombies,String nombre) {
        initComponents();
        Player_1 = new Player_1();
        Player_2 = new Player_2();
        Neutral_A = new Neutral_A();
        Neutral_B = new Neutral_B();
        Neutral_C = new Neutral_C();
        Neutral_D = new Neutral_D();
        Neutral_E = new Neutral_E();
        Neutral_F = new Neutral_F();
        Neutral_G = new Neutral_G();
        Neutral_H = new Neutral_H();
        Neutral_I = new Neutral_I();
        Neutral_J = new Neutral_J();
        Zombie_A = new Zombie_A();
        Zombie_B = new Zombie_B();
        Zombie_C = new Zombie_C();
        Zombie_D = new Zombie_D();
        Zombie_E = new Zombie_E();
        Zombie_F = new Zombie_F();
        Zombie_G = new Zombie_G();
        Zombie_H = new Zombie_H();
        Zombie_I = new Zombie_I();
        Zombie_J = new Zombie_J();
        this.ciego = ciego;
        this.produccion = produccion;
        this.distribuir = distribuir;
        this.naves = naves;
        this.atributos = atributos;
        this.anchura = anchura;
        this.altura = altura;
        this.turnos = turnos;
        this.neutrales = neutrales;
        this.zombies = zombies;
        this.nombre = nombre;
    // Arreglos Jugador 1
        planetasDelJU[0] = "Player_1"; planetasDelJU[1] = null; planetasDelJU[2] = null; planetasDelJU[3] = null; planetasDelJU[4] = null; planetasDelJU[5] = null; planetasDelJU[6] = null; planetasDelJU[7] = null; planetasDelJU[8] = null; planetasDelJU[9] = null;
        turnosAtaquesJugadorUno[0] = 100; turnosAtaquesJugadorUno[1] = 100; turnosAtaquesJugadorUno[2] = 100; turnosAtaquesJugadorUno[3] = 100; turnosAtaquesJugadorUno[4] = 100; turnosAtaquesJugadorUno[5] = 100; turnosAtaquesJugadorUno[6] = 100; turnosAtaquesJugadorUno[7] = 100; turnosAtaquesJugadorUno[8] = 100; turnosAtaquesJugadorUno[9] = 100;
        planetasQueAtacanJU[0] = null; planetasQueAtacanJU[1] = null; planetasQueAtacanJU[2] = null; planetasQueAtacanJU[3] = null; planetasQueAtacanJU[4] = null; planetasQueAtacanJU[5] = null; planetasQueAtacanJU[6] = null; planetasQueAtacanJU[7] = null; planetasQueAtacanJU[8] = null; planetasQueAtacanJU[9] = null;
        planetasAAtacarJU[0] = null; planetasAAtacarJU[1] = null; planetasAAtacarJU[2] = null; planetasAAtacarJU[3] = null; planetasAAtacarJU[4] = null; planetasAAtacarJU[5] = null; planetasAAtacarJU[6] = null; planetasAAtacarJU[7] = null; planetasAAtacarJU[8] = null; planetasAAtacarJU[9] = null;
        numeroDeTropasJUA[0] = 0; numeroDeTropasJUA[1] = 0; numeroDeTropasJUA[2] = 0; numeroDeTropasJUA[3] = 0; numeroDeTropasJUA[4] = 0; numeroDeTropasJUA[5] = 0; numeroDeTropasJUA[6] = 0; numeroDeTropasJUA[7] = 0; numeroDeTropasJUA[8] = 0; numeroDeTropasJUA[9] = 0;
        turnosRefuerzosJugadorUno[0] = 100; turnosRefuerzosJugadorUno[1] = 100; turnosRefuerzosJugadorUno[2] = 100; turnosRefuerzosJugadorUno[3] = 100; turnosRefuerzosJugadorUno[4] = 100; turnosRefuerzosJugadorUno[5] = 100; turnosRefuerzosJugadorUno[6] = 100; turnosRefuerzosJugadorUno[7] = 100; turnosRefuerzosJugadorUno[8] = 100; turnosRefuerzosJugadorUno[9] = 100; 
        planetasAReforzarJU[0] = null; planetasAReforzarJU[1] = null; planetasAReforzarJU[2] = null; planetasAReforzarJU[3] = null; planetasAReforzarJU[4] = null; planetasAReforzarJU[5] = null; planetasAReforzarJU[6] = null; planetasAReforzarJU[7] = null; planetasAReforzarJU[8] = null; planetasAReforzarJU[9] = null;
        numeroDeTropasJUR[0] = 0; numeroDeTropasJUR[1] = 0; numeroDeTropasJUR[2] = 0; numeroDeTropasJUR[3] = 0; numeroDeTropasJUR[4] = 0; numeroDeTropasJUR[5] = 0; numeroDeTropasJUR[6] = 0; numeroDeTropasJUR[7] = 0; numeroDeTropasJUR[8] = 0; numeroDeTropasJUR[9] = 0; 
    // Arreglos Jugador 2
        planetasDelJD[0] = "Player_2"; planetasDelJD[1] = null; planetasDelJD[3] = null; planetasDelJD[4] = null; planetasDelJD[5] = null; planetasDelJD[6] = null; planetasDelJD[7] = null; planetasDelJD[8] = null; planetasDelJD[9] = null;
        turnosAtaquesJugadorDos[0] = 100; turnosAtaquesJugadorDos[1] = 100; turnosAtaquesJugadorDos[2] = 100; turnosAtaquesJugadorDos[3] = 100; turnosAtaquesJugadorDos[4] = 100; turnosAtaquesJugadorDos[5] = 100; turnosAtaquesJugadorDos[6] = 100; turnosAtaquesJugadorDos[7] = 100; turnosAtaquesJugadorDos[8] = 100; turnosAtaquesJugadorDos[9] = 100;
        planetasQueAtacanJD[0] = null; planetasQueAtacanJD[1] = null; planetasQueAtacanJD[2] = null; planetasQueAtacanJD[3] = null; planetasQueAtacanJD[4] = null; planetasQueAtacanJD[5] = null; planetasQueAtacanJD[6] = null; planetasQueAtacanJD[7] = null; planetasQueAtacanJD[8] = null; planetasQueAtacanJD[9] = null;
        planetasAAtacarJD[0] = null; planetasAAtacarJD[1] = null; planetasAAtacarJD[2] = null; planetasAAtacarJD[3] = null; planetasAAtacarJD[4] = null; planetasAAtacarJD[5] = null; planetasAAtacarJD[6] = null; planetasAAtacarJD[7] = null; planetasAAtacarJD[8] = null; planetasAAtacarJD[9] = null;
        numeroDeTropasJDA[0] = 0; numeroDeTropasJDA[1] = 0; numeroDeTropasJDA[2] = 0; numeroDeTropasJDA[3] = 0; numeroDeTropasJDA[4] = 0; numeroDeTropasJDA[5] = 0; numeroDeTropasJDA[6] = 0; numeroDeTropasJDA[7] = 0; numeroDeTropasJDA[8] = 0; numeroDeTropasJDA[9] = 0;
        turnosRefuerzosJugadorDos[0] = 100; turnosRefuerzosJugadorDos[1] = 100; turnosRefuerzosJugadorDos[2] = 100; turnosRefuerzosJugadorDos[3] = 100; turnosRefuerzosJugadorDos[4] = 100; turnosRefuerzosJugadorDos[5] = 100; turnosRefuerzosJugadorDos[6] = 100; turnosRefuerzosJugadorDos[7] = 100; turnosRefuerzosJugadorDos[8] = 100; turnosRefuerzosJugadorDos[9] = 100; 
        planetasAReforzarJD[0] = null; planetasAReforzarJD[1] = null; planetasAReforzarJD[2] = null; planetasAReforzarJD[3] = null; planetasAReforzarJD[4] = null; planetasAReforzarJD[5] = null; planetasAReforzarJD[6] = null; planetasAReforzarJD[7] = null; planetasAReforzarJD[8] = null; planetasAReforzarJD[9] = null;
        numeroDeTropasJDR[0] = 0; numeroDeTropasJDR[1] = 0; numeroDeTropasJDR[2] = 0; numeroDeTropasJDR[3] = 0; numeroDeTropasJDR[4] = 0; numeroDeTropasJDR[5] = 0; numeroDeTropasJDR[6] = 0; numeroDeTropasJDR[7] = 0; numeroDeTropasJDR[8] = 0; numeroDeTropasJDR[9] = 0; 
    // Controles
        numeroAtaque.setEnabled(false);
	enviarA.setEnabled(false);
	numeroRefuerzo.setEnabled(false);
	enviarR.setEnabled(false);
        letreroDelJugEnTurno.setText("Turno Player_1");
        numeroDeTurno.setText("turno: " + turno);
        organizarPlanetas();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator4 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel3 = new javax.swing.JPanel();
        Mensajes = new javax.swing.JLabel();
        linea1 = new javax.swing.JLabel();
        linea2 = new javax.swing.JLabel();
        linea3 = new javax.swing.JLabel();
        linea4 = new javax.swing.JLabel();
        linea5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        letreroDelJugEnTurno = new javax.swing.JLabel();
        volverASeleccionar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        enviarA = new javax.swing.JButton();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        enviarR = new javax.swing.JButton();
        numeroDeTurno = new javax.swing.JLabel();
        confirmarCoordenadas = new javax.swing.JButton();
        numeroAtaque = new javax.swing.JSpinner();
        numeroRefuerzo = new javax.swing.JSpinner();
        jSeparator11 = new javax.swing.JSeparator();
        jPanel1 = new javax.swing.JPanel();
        terminarTurno = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        mapa0 = new javax.swing.JLabel();
        mapa1 = new javax.swing.JLabel();
        mapa2 = new javax.swing.JLabel();
        mapa3 = new javax.swing.JLabel();
        mapa4 = new javax.swing.JLabel();
        mapa5 = new javax.swing.JLabel();
        mapa6 = new javax.swing.JLabel();
        mapa7 = new javax.swing.JLabel();
        mapa8 = new javax.swing.JLabel();
        mapa9 = new javax.swing.JLabel();
        mapa10 = new javax.swing.JLabel();
        mapa11 = new javax.swing.JLabel();
        mapa12 = new javax.swing.JLabel();
        mapa13 = new javax.swing.JLabel();
        mapa14 = new javax.swing.JLabel();
        mapa15 = new javax.swing.JLabel();
        mapa16 = new javax.swing.JLabel();
        mapa17 = new javax.swing.JLabel();
        mapa18 = new javax.swing.JLabel();
        mapa19 = new javax.swing.JLabel();
        mapa20 = new javax.swing.JLabel();
        mapa21 = new javax.swing.JLabel();
        mapa22 = new javax.swing.JLabel();
        mapa23 = new javax.swing.JLabel();
        mapa24 = new javax.swing.JLabel();
        mapa25 = new javax.swing.JLabel();
        mapa26 = new javax.swing.JLabel();
        mapa27 = new javax.swing.JLabel();
        mapa28 = new javax.swing.JLabel();
        mapa29 = new javax.swing.JLabel();
        mapa30 = new javax.swing.JLabel();
        mapa31 = new javax.swing.JLabel();
        mapa32 = new javax.swing.JLabel();
        mapa33 = new javax.swing.JLabel();
        mapa34 = new javax.swing.JLabel();
        mapa35 = new javax.swing.JLabel();
        mapa36 = new javax.swing.JLabel();
        mapa37 = new javax.swing.JLabel();
        mapa38 = new javax.swing.JLabel();
        mapa39 = new javax.swing.JLabel();
        mapa40 = new javax.swing.JLabel();
        mapa41 = new javax.swing.JLabel();
        mapa42 = new javax.swing.JLabel();
        mapa43 = new javax.swing.JLabel();
        mapa44 = new javax.swing.JLabel();
        mapa45 = new javax.swing.JLabel();
        mapa46 = new javax.swing.JLabel();
        mapa47 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Batalla");
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        Mensajes.setText("Mensajes");

        linea1.setText("El Player_1 conquisto el Planeta F");

        linea2.setText("El Player_2 ataco al Player_1 pero resistio al Ataque");

        linea3.setText("El Player_1 mando refuerzos al Planeta F");

        linea4.setText("El Player_1 coquisto un planeta del Player_2");

        linea5.setText("El Player_1 a Ganado");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(Mensajes)
                    .addComponent(linea1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(linea2, javax.swing.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                    .addComponent(linea3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(linea4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(linea5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Mensajes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linea1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linea2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linea3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linea4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(linea5)
                .addGap(22, 22, 22))
        );

        letreroDelJugEnTurno.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        letreroDelJugEnTurno.setText(" ");

        volverASeleccionar.setText("Volver a Seleccionar");
        volverASeleccionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverASeleccionarActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Ataque: ");

        jLabel6.setText("Coloque el No. de Tropas que enviará a la Batalla");

        enviarA.setText("Atacar");
        enviarA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarAActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Enviar:");

        jLabel8.setText("Coloque el No. de Tropas que enviará como Refuerzo");

        enviarR.setText("Reforzar");
        enviarR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enviarRActionPerformed(evt);
            }
        });

        confirmarCoordenadas.setText("Confirmar Coordenadas");
        confirmarCoordenadas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmarCoordenadasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(numeroAtaque, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(enviarA))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(numeroRefuerzo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(enviarR))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addComponent(confirmarCoordenadas)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(volverASeleccionar))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(letreroDelJugEnTurno, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(numeroDeTurno, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel6))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel8)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(letreroDelJugEnTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(numeroDeTurno, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(volverASeleccionar)
                    .addComponent(confirmarCoordenadas))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(enviarA)
                    .addComponent(numeroAtaque, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(enviarR)
                    .addComponent(numeroRefuerzo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jSeparator11.setOrientation(javax.swing.SwingConstants.VERTICAL);

        terminarTurno.setText("Terminar Turno");
        terminarTurno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                terminarTurnoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(163, Short.MAX_VALUE)
                .addComponent(terminarTurno)
                .addGap(7, 7, 7))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(terminarTurno)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        mapa0.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa0MouseClicked(evt);
            }
        });

        mapa1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa1MouseClicked(evt);
            }
        });

        mapa2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa2MouseClicked(evt);
            }
        });

        mapa3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa3MouseClicked(evt);
            }
        });

        mapa4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa4MouseClicked(evt);
            }
        });

        mapa5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa5MouseClicked(evt);
            }
        });

        mapa6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa6MouseClicked(evt);
            }
        });

        mapa7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa7MouseClicked(evt);
            }
        });

        mapa8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa8MouseClicked(evt);
            }
        });

        mapa9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa9MouseClicked(evt);
            }
        });

        mapa10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa10MouseClicked(evt);
            }
        });

        mapa11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa11MouseClicked(evt);
            }
        });

        mapa12.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa12MouseClicked(evt);
            }
        });

        mapa13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa13MouseClicked(evt);
            }
        });

        mapa14.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa14MouseClicked(evt);
            }
        });

        mapa15.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa15MouseClicked(evt);
            }
        });

        mapa16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa16MouseClicked(evt);
            }
        });

        mapa17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa17MouseClicked(evt);
            }
        });

        mapa18.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa18MouseClicked(evt);
            }
        });

        mapa19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa19MouseClicked(evt);
            }
        });

        mapa20.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa20MouseClicked(evt);
            }
        });

        mapa21.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa21MouseClicked(evt);
            }
        });

        mapa22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa22MouseClicked(evt);
            }
        });

        mapa23.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa23MouseClicked(evt);
            }
        });

        mapa24.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa24MouseClicked(evt);
            }
        });

        mapa25.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa25MouseClicked(evt);
            }
        });

        mapa26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa26MouseClicked(evt);
            }
        });

        mapa27.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa27MouseClicked(evt);
            }
        });

        mapa28.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa28MouseClicked(evt);
            }
        });

        mapa29.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa29MouseClicked(evt);
            }
        });

        mapa30.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa30MouseClicked(evt);
            }
        });

        mapa31.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa31MouseClicked(evt);
            }
        });

        mapa32.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa32MouseClicked(evt);
            }
        });

        mapa33.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa33MouseClicked(evt);
            }
        });

        mapa34.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa34MouseClicked(evt);
            }
        });

        mapa35.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa35MouseClicked(evt);
            }
        });

        mapa36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa36MouseClicked(evt);
            }
        });

        mapa37.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa37MouseClicked(evt);
            }
        });

        mapa38.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa38MouseClicked(evt);
            }
        });

        mapa39.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa39MouseClicked(evt);
            }
        });

        mapa40.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa40MouseClicked(evt);
            }
        });

        mapa41.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa41MouseClicked(evt);
            }
        });

        mapa42.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa42MouseClicked(evt);
            }
        });

        mapa43.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa43MouseClicked(evt);
            }
        });

        mapa44.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa44MouseClicked(evt);
            }
        });

        mapa45.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa45MouseClicked(evt);
            }
        });

        mapa46.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa46MouseClicked(evt);
            }
        });

        mapa47.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mapa47MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(mapa40, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa32, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa33, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa34, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa35, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa36, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa29, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa30, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa31, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa7, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa0, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa8, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa16, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa24, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mapa32, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa33, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa38, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mapa40, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(mapa41, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa42, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa43, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa45, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa46, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(mapa47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 660, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jSeparator5))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 3, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator11)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(2, 2, 2)
                                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 4, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void mapa0MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa0MouseClicked
        int fila = 0;
	int columna = 0;
	emisor = mapa[0][0];
	verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa0MouseClicked

    private void mapa1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa1MouseClicked
        int fila = 0;
	int columna = 1;
	emisor = mapa[0][1];
	verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa1MouseClicked

    private void mapa2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa2MouseClicked
        int fila = 0;
        int columna = 2;
        emisor = mapa[0][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa2MouseClicked

    private void mapa3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa3MouseClicked
        int fila = 0;
        int columna = 3;
        emisor = mapa[0][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa3MouseClicked

    private void mapa4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa4MouseClicked
        int fila = 0;
        int columna = 4;
        emisor = mapa[0][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa4MouseClicked

    private void mapa5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa5MouseClicked
        int fila = 0;
        int columna = 5;
        emisor = mapa[0][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa5MouseClicked

    private void mapa6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa6MouseClicked
        int fila = 0;
        int columna = 6;
        emisor = mapa[0][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa6MouseClicked

    private void mapa7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa7MouseClicked
        int fila = 0;
        int columna = 7;
        emisor = mapa[0][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa7MouseClicked

    private void mapa8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa8MouseClicked
        int fila = 1;
        int columna = 0;
        emisor = mapa[1][0];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa8MouseClicked

    private void mapa9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa9MouseClicked
        int fila = 1;
        int columna = 1;
        emisor = mapa[1][1];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa9MouseClicked

    private void mapa10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa10MouseClicked
        int fila = 1;
        int columna = 2;
        emisor = mapa[1][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa10MouseClicked

    private void mapa11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa11MouseClicked
        int fila = 1;
        int columna = 3;
        emisor = mapa[1][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa11MouseClicked

    private void mapa12MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa12MouseClicked
        int fila = 1;
        int columna = 4;
        emisor = mapa[1][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa12MouseClicked

    private void mapa13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa13MouseClicked
        int fila = 1;
        int columna = 5;
        emisor = mapa[1][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa13MouseClicked

    private void mapa14MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa14MouseClicked
        int fila = 1;
        int columna = 6;
        emisor = mapa[1][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa14MouseClicked

    private void mapa15MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa15MouseClicked
        int fila = 1;
        int columna = 7;
        emisor = mapa[1][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa15MouseClicked

    private void mapa16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa16MouseClicked
        int fila = 2;
        int columna = 0;
        emisor = mapa[2][0];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa16MouseClicked

    private void mapa17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa17MouseClicked
        int fila = 2;
        int columna = 1;
        emisor = mapa[2][1];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa17MouseClicked

    private void mapa18MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa18MouseClicked
        int fila = 2;
        int columna = 2;
        emisor = mapa[2][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa18MouseClicked

    private void mapa19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa19MouseClicked
        int fila = 2;
        int columna = 3;
        emisor = mapa[2][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa19MouseClicked

    private void mapa20MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa20MouseClicked
        int fila = 2;
        int columna = 4;
        emisor = mapa[2][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa20MouseClicked

    private void mapa21MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa21MouseClicked
        int fila = 2;
        int columna = 5;
        emisor = mapa[2][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa21MouseClicked

    private void mapa22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa22MouseClicked
        int fila = 2;
        int columna = 6;
        emisor = mapa[2][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa22MouseClicked

    private void mapa23MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa23MouseClicked
        int fila = 2;
        int columna = 7;
        emisor = mapa[2][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa23MouseClicked

    private void mapa24MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa24MouseClicked
        int fila = 3;
        int columna = 0;
        emisor = mapa[3][0];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa24MouseClicked

    private void mapa25MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa25MouseClicked
        int fila = 3;
        int columna = 1;
        emisor = mapa[3][1];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa25MouseClicked

    private void mapa26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa26MouseClicked
        int fila = 3;
        int columna = 2;
        emisor = mapa[3][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa26MouseClicked

    private void mapa27MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa27MouseClicked
        int fila = 3;
        int columna = 3;
        emisor = mapa[3][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa27MouseClicked

    private void mapa28MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa28MouseClicked
        int fila = 3;
        int columna = 4;
        emisor = mapa[3][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa28MouseClicked

    private void mapa29MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa29MouseClicked
        int fila = 3;
        int columna = 5;
        emisor = mapa[3][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa29MouseClicked

    private void mapa30MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa30MouseClicked
        int fila = 3;
        int columna = 6;
        emisor = mapa[3][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa30MouseClicked

    private void mapa31MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa31MouseClicked
        int fila = 3;
        int columna = 7;
        emisor = mapa[3][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa31MouseClicked

    private void mapa32MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa32MouseClicked
        int fila = 4;
        int columna = 0;
        emisor = mapa[4][0];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa32MouseClicked

    private void mapa33MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa33MouseClicked
        int fila = 4;
        int columna = 1;
        emisor = mapa[4][1];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa33MouseClicked

    private void mapa34MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa34MouseClicked
        int fila = 4;
        int columna = 2;
        emisor = mapa[4][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa34MouseClicked

    private void mapa35MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa35MouseClicked
        int fila = 4;
        int columna = 3;
        emisor = mapa[4][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa35MouseClicked

    private void mapa36MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa36MouseClicked
        int fila = 4;
        int columna = 4;
        emisor = mapa[4][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa36MouseClicked

    private void mapa37MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa37MouseClicked
        int fila = 4;
        int columna = 5;
        emisor = mapa[4][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa37MouseClicked

    private void mapa38MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa38MouseClicked
        int fila = 4;
        int columna = 6;
        emisor = mapa[4][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa38MouseClicked

    private void mapa39MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa39MouseClicked
        int fila = 4;
        int columna = 7;
        emisor = mapa[4][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa39MouseClicked

    private void mapa40MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa40MouseClicked
        int fila = 5;
        int columna = 0;
        emisor = mapa[5][0];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa40MouseClicked

    private void mapa41MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa41MouseClicked
        int fila = 5;
        int columna = 1;
        emisor = mapa[5][1];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa41MouseClicked

    private void mapa42MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa42MouseClicked
        int fila = 5;
        int columna = 2;
        emisor = mapa[5][2];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa42MouseClicked

    private void mapa43MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa43MouseClicked
        int fila = 5;
        int columna = 3;
        emisor = mapa[5][3];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa43MouseClicked

    private void mapa44MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa44MouseClicked
        int fila = 5;
        int columna = 4;
        emisor = mapa[5][4];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa44MouseClicked

    private void mapa45MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa45MouseClicked
        int fila = 5;
        int columna = 5;
        emisor = mapa[5][5];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa45MouseClicked

    private void mapa46MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa46MouseClicked
        int fila = 5;
        int columna = 6;
        emisor = mapa[5][6];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa46MouseClicked

    private void mapa47MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mapa47MouseClicked
        int fila = 5;
        int columna = 7;
        emisor = mapa[5][7];
        verificarCoordenadas(fila,columna);
    }//GEN-LAST:event_mapa47MouseClicked

    private void confirmarCoordenadasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmarCoordenadasActionPerformed
        if (coordenada == 2) {
            abrirAccesos();
            confirmarCoordenadas.setEnabled(false);
            volverASeleccionar.setEnabled(false);
	} else {
            JOptionPane.showMessageDialog(this,"Debes terminar de seleccionar las Coordenadas","Error",JOptionPane.ERROR_MESSAGE);
	}
    }//GEN-LAST:event_confirmarCoordenadasActionPerformed

    private void volverASeleccionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverASeleccionarActionPerformed
        coordenada = 0;
	filaInicio = 0;
	filaFinal = 0;
	columnaInicio = 0;
	columnaFinal = 0;
	planetaEmisor = null;
	emisor = null;
	abrir = 0;
	numeroAtaque.setEnabled(false);
	enviarA.setEnabled(false);
	numeroRefuerzo.setEnabled(false);
	enviarR.setEnabled(false);
	JOptionPane.showMessageDialog(this,"Puedes volver a Seleccionar","Empezar",JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_volverASeleccionarActionPerformed

    private void enviarAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enviarAActionPerformed
        if (obtenerNumeroAtaque() != 0) {
            if (jugadorEnTurno == 1) {
                if (verificarTropas()) {
                    restarTropas();
                    for (int i = 0; i < 10; i++) {
                        if (turnosAtaquesJugadorUno[i] == 100) {
                            turnosAtaquesJugadorUno[i] = contarDistancia() + turno;
                            planetasQueAtacanJU[i] = planetaEmisor;
                            planetasAAtacarJU[i] = emisor;
                            numeroDeTropasJUA[i] = obtenerNumeroAtaque();
                            break;
                        }
                    }
                    organizarTurnos();
                    enviarA.setEnabled(false);
                    numeroAtaque.setEnabled(false);
                    coordenada = 0;
                } else {
                    JOptionPane.showMessageDialog(this,"No tienes ese número de Tropas disponibles en este Planeta","Estado de las Tropas",JOptionPane.ERROR_MESSAGE);
                }
            } else {	
                if (verificarTropas()) {
                    restarTropas();
                    for (int i = 0; i < 10; i++) {
                        if (turnosAtaquesJugadorDos[i] == 100) {
                            turnosAtaquesJugadorDos[i] = contarDistancia() + turno;
                            planetasQueAtacanJD[i] = planetaEmisor;
                            planetasAAtacarJD[i] = emisor;
                            numeroDeTropasJDA[i] = obtenerNumeroAtaque();
                            break;
                        }
                    }
                    organizarTurnos();
                    enviarA.setEnabled(false);
                    numeroAtaque.setEnabled(false);
                    coordenada = 0;
                } else {
                    JOptionPane.showMessageDialog(this,"No tienes ese número de Tropas disponibles en este Planeta","Estado de las Tropas",JOptionPane.ERROR_MESSAGE);
                }
            }
            confirmarCoordenadas.setEnabled(true);
            volverASeleccionar.setEnabled(true);
	} else {
            JOptionPane.showMessageDialog(this,"Las tropas no pueden ser 0","Tropas",JOptionPane.ERROR_MESSAGE);
	}
    }//GEN-LAST:event_enviarAActionPerformed

    private void enviarRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enviarRActionPerformed
        if (obtenerNumeroRefuerzo() != 0) {
            if (jugadorEnTurno == 1) {
                if (verificarTropas()) {
                    restarTropas();
                    for (int i = 0; i < 10; i++) {
                        if (turnosRefuerzosJugadorUno[i] == 0) {
                            turnosRefuerzosJugadorUno[i] = contarDistancia() + turno;
                            planetasAReforzarJU[i] = emisor;
                            numeroDeTropasJUR[i] = obtenerNumeroRefuerzo();
                            break;
                        }
                    }
                    organizarTurnos1();
                    enviarR.setEnabled(false);
                    numeroRefuerzo.setEnabled(false);
                    coordenada = 0;
                } else {
                    JOptionPane.showMessageDialog(this,"No tienes ese número de Tropas disponibles en este Planeta","Estado de las Tropas",JOptionPane.ERROR_MESSAGE);
                }
            } else {	
                if (verificarTropas()) {
                    restarTropas();
                    for (int i = 0; i < 10; i++) {
                        if (turnosRefuerzosJugadorDos[i] == 0) {
                            turnosRefuerzosJugadorDos[i] = contarDistancia() + turno;
                            planetasAReforzarJD[i] = emisor;
                            numeroDeTropasJDR[i] = obtenerNumeroRefuerzo();
                            break;
                        }
                    }
                    organizarTurnos1();
                    enviarA.setEnabled(false);
                    numeroRefuerzo.setEnabled(false);
                    coordenada = 0;
                } else {
                    JOptionPane.showMessageDialog(this,"No tienes ese número de Tropas disponibles en este Planeta","Estado de las Tropas",JOptionPane.ERROR_MESSAGE);
                }
            }
            confirmarCoordenadas.setEnabled(true);
            volverASeleccionar.setEnabled(true);
	} else {
            JOptionPane.showMessageDialog(this,"Las tropas no pueden ser 0","Tropas",JOptionPane.ERROR_MESSAGE);
	}
    }//GEN-LAST:event_enviarRActionPerformed

    private void terminarTurnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminarTurnoActionPerformed
        turno++;
	
	if (turno <= turnos) {
            for (int i = 0; i < 10; i++) {
                if (turno == turnosAtaquesJugadorUno[0]) {
                    naves1 = numeroDeTropasJUA[0];
                    porcentaje1 = mandarPorcentaje(planetasQueAtacanJU[0]);
                    naves2 = mandarNaves(planetasAAtacarJU[0]);
                    porcentaje2 = mandarPorcentaje(planetasAAtacarJU[0]);
                    mandarAtaque(planetasQueAtacanJU[0], planetasAAtacarJU[0]);
                    acceso = 0;
                }
                if (turno == turnosRefuerzosJugadorUno[0]) {
                    naves1 = numeroDeTropasJUR[0];
                    mandarRefuerzos(planetasAReforzarJU[0]);
                }
                if (turno == turnosAtaquesJugadorDos[0]) {
                    naves1 = numeroDeTropasJDA[0];
                    porcentaje1 = mandarPorcentaje(planetasQueAtacanJD[0]);
                    naves2 = mandarNaves(planetasAAtacarJD[0]);
                    porcentaje2 = mandarPorcentaje(planetasAAtacarJD[0]);
                    mandarAtaque(planetasQueAtacanJD[0], planetasAAtacarJD[0]);
                    acceso = 1;
                }
                if (turno == turnosRefuerzosJugadorDos[0]) {
                    naves1 = numeroDeTropasJDR[0];
                    mandarRefuerzos(planetasAReforzarJD[0]);
                }
            }     
            
            if (jugadorEnTurno == 1) {
                jugadorEnTurno = 2;
                letreroDelJugEnTurno.setText("Turno Player_2");
            } else {
                jugadorEnTurno = 1;
                letreroDelJugEnTurno.setText("Turno Player_1");
            }
            numeroDeTurno.setText("turno: " + turno);
            
            int contador = 0;
            int contador1 = 0;
            
            for (int i = 0; i < 10; i++) {
                if (planetasDelJU[i] != null) {
                    contador++;
                }
            }
            for (int i = 0; i < 10; i++) {
                if (planetasDelJD[i] != null) {
                    contador1++;
                }
            }
            /*
            if (contador == 0) {
                JOptionPane.showMessageDialog(this,"El Player_1 se quedo sin Planetas, Gana el Player_2","Ganador",JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
            }
            if (contador1 == 0) {
                JOptionPane.showMessageDialog(this,"El Player_2 se quedo sin Planetas, Gana el Player_1","Ganador",JOptionPane.INFORMATION_MESSAGE);
                this.dispose();
            }
            */
	} else {
            JOptionPane.showMessageDialog(this,"Ya no hay más turnos, termino el juego","Fin del Juego",JOptionPane.INFORMATION_MESSAGE);
            int contador = 0;
            int contador1 = 0;
            
            for (int i = 0; i < 10; i++) {
                if (planetasDelJU[i] != null) {
                    contador++;
                }
            }
            for (int i = 0; i < 10; i++) {
                if (planetasDelJD[i] != null) {
                    contador1++;
                }
            }
            if (contador > contador1) {
                contador--;
                JOptionPane.showMessageDialog(this,"El Player_1 ganó ya que conquisto " + contador + " planetas","Ganador",JOptionPane.INFORMATION_MESSAGE);
            }
            if (contador1 > contador) {
                contador1--;
                JOptionPane.showMessageDialog(this,"El Player_2 ganó ya que conquisto " + contador1 + " planetas","Ganador",JOptionPane.INFORMATION_MESSAGE);
            }
            if (contador1 == contador) {
                contador--;
                JOptionPane.showMessageDialog(this,"Empate, ambos Jugadores conquistaron " + contador + " planetas","Empate",JOptionPane.INFORMATION_MESSAGE);
            }
            this.dispose();
	}
    }//GEN-LAST:event_terminarTurnoActionPerformed

    private void verificarCoordenadas(int fila, int columna) {
        switch (coordenada) {
            case 0 -> {
                if (verificarPlaneta()) {
                    JOptionPane.showMessageDialog(this,"Coordenada Guardada, seleccione el lugar de destino","Guardado",JOptionPane.INFORMATION_MESSAGE);
                    filaInicio = fila;
                    columnaInicio = columna;
                    coordenada++;
                } else {
                    JOptionPane.showMessageDialog(this,"No puedes realizar ninguna acción desde esta posición","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
            case 1 -> {
                if (!emisor.equals(planetaEmisor)) {
                    if (verificarPlaneta2()) {
                        filaFinal = fila;
                        columnaFinal = columna;
                        if (turnos >= contarDistancia()) {
                            JOptionPane.showMessageDialog(this,"El destino es el Planeta " + emisor + " y las tropas llegarán en " + contarDistancia() + " turnos","Verificación",JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(this,"Si estas deacuerdo, pulsa (Confirmar Coordenadas), de lo contrario pulsa (Volver a Seleccionar)","Confirmar Coordenadas",JOptionPane.INFORMATION_MESSAGE);
                            coordenada++;
                        } else {
                            JOptionPane.showMessageDialog(this,"No hay suficientes turnos para ir a este Planeta, selecciona otro destino","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(this,"No puedes realizar ninguna acción hacia esta posición","Error",JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this,"No puedes realizar ninguna acción hacia esta posición","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
            default -> JOptionPane.showMessageDialog(this,"Ya no puedes seleccionar otra Coordenada","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean verificarPlaneta() {
	boolean permitir = false;
	
	if (jugadorEnTurno == 1) {
            for (int i = 0; i < 10; i++) {
		if (emisor.equals(planetasDelJU[i])) {
                    permitir = true;
                    planetaEmisor = emisor;
                    break;
                }
            }
	} else 	{
            for (int i = 0; i < 10; i++) {
		if (emisor.equals(planetasDelJD[i])) {
                    permitir = true;
                    planetaEmisor = emisor;
                    break;
		}
            }
	}
	return permitir;
    }
    
    private boolean verificarPlaneta2() {
	boolean permitir = false;
	int entrar = 0;
	
	if (jugadorEnTurno == 1) {
            for (int i = 0; i < 10; i++) {
                if (emisor.equals(planetasDelJU[i])) {
                    permitir = true;
                    entrar = 1;
                    abrir = 1;
                    break;
                }
            }
            if (entrar == 0) {
                if (!"Espacio".equals(emisor)) {
                    permitir = true;
                    abrir = 0;
                }
            }	
	} else {
            for (int i = 0; i < 10; i++) {
                if (emisor.equals(planetasDelJD[i])) {
                    permitir = true;
                    entrar = 1;
                    abrir = 1;
                    break;
                }
            }
            if (entrar == 0) {
                if (!"Espacio".equals(emisor)) {
                    permitir = true;
                    abrir = 0;
                }
            }	
	}
	return permitir;
    }
    
    private int contarDistancia() {
        int distancia = 0;
	int ancho = 0;
	int altura = 0;
	
	if (filaInicio <= filaFinal) {
            altura = filaFinal - filaInicio;
	} else {
            altura = filaInicio - filaFinal;
	}
	if (columnaInicio <= columnaFinal) {
            ancho = columnaFinal - columnaInicio;
	} else {
            ancho = columnaInicio - columnaFinal;
	}
	return distancia = altura + ancho;
    }
    
    private void abrirAccesos() {
	if (abrir == 1) {
            numeroRefuerzo.setEnabled(true);
            enviarR.setEnabled(true);
            numeroAtaque.setEnabled(false);
            enviarA.setEnabled(false);
	} else if (abrir == 0) {	
            numeroAtaque.setEnabled(true);
            enviarA.setEnabled(true);
            numeroRefuerzo.setEnabled(false);
            enviarR.setEnabled(false);
	}
    }
    
    private boolean verificarTropas() {
	boolean comparacion = false;
	
	if ("Player_1".equals(planetaEmisor)) {
            comparacion = Player_1.compararTropas(obtenerNumeroAtaque());
	}
	if ("Player_2".equals(planetaEmisor)) {
            comparacion = Player_2.compararTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_A".equals(planetaEmisor)) {
            comparacion = Neutral_A.compararTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_B".equals(planetaEmisor)) {
            comparacion = Neutral_B.compararTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_C".equals(planetaEmisor)) {
            comparacion = Neutral_C.compararTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_D".equals(planetaEmisor)) {
            comparacion = Neutral_D.compararTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_E".equals(planetaEmisor)) {
            comparacion = Neutral_E.compararTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_F".equals(planetaEmisor)) {
            comparacion = Neutral_F.compararTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_G".equals(planetaEmisor)) {
            comparacion = Neutral_G.compararTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_H".equals(planetaEmisor)) {
            comparacion = Neutral_H.compararTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_I".equals(planetaEmisor)) {
            comparacion = Neutral_I.compararTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_J".equals(planetaEmisor)) {
            comparacion = Neutral_J.compararTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_A".equals(planetaEmisor)) {
            comparacion = Zombie_A.compararTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_B".equals(planetaEmisor)) {
            comparacion = Zombie_B.compararTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_C".equals(planetaEmisor)) {
            comparacion = Zombie_C.compararTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_D".equals(planetaEmisor)) {
            comparacion = Zombie_D.compararTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_E".equals(planetaEmisor)) {
            comparacion = Zombie_E.compararTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_F".equals(planetaEmisor)) {
            comparacion = Zombie_F.compararTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_G".equals(planetaEmisor)) {
            comparacion = Zombie_G.compararTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_H".equals(planetaEmisor)) {
            comparacion = Zombie_H.compararTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_I".equals(planetaEmisor)) {
            comparacion = Zombie_I.compararTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_J".equals(planetaEmisor)) {
            comparacion = Zombie_J.compararTropas(obtenerNumeroAtaque());
	}
	return comparacion;
    }
    
    private void restarTropas() {
	if ("Player_1".equals(planetaEmisor)) {
            Player_1.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Player_2".equals(planetaEmisor)) {
            Player_2.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_A".equals(planetaEmisor)) {
            Neutral_A.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_B".equals(planetaEmisor)) {
            Neutral_B.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_C".equals(planetaEmisor)) {
            Neutral_C.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_D".equals(planetaEmisor)) {
            Neutral_D.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_E".equals(planetaEmisor)) {
            Neutral_E.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_F".equals(planetaEmisor)) {
            Neutral_F.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_G".equals(planetaEmisor)) {
            Neutral_G.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_H".equals(planetaEmisor)) {
            Neutral_H.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Neutral_I".equals(planetaEmisor)) {
            Neutral_I.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Neutral_J".equals(planetaEmisor)) {
            Neutral_J.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_A".equals(planetaEmisor)) {
            Zombie_A.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_B".equals(planetaEmisor)) {
            Zombie_B.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_C".equals(planetaEmisor)) {
            Zombie_C.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_D".equals(planetaEmisor)) {
            Zombie_D.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_E".equals(planetaEmisor)) {
            Zombie_E.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_F".equals(planetaEmisor)) {
            Zombie_F.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_G".equals(planetaEmisor)) {
            Zombie_G.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_H".equals(planetaEmisor)) {
            Zombie_H.sustraerTropas(obtenerNumeroAtaque());
	}
        if ("Zombie_I".equals(planetaEmisor)) {
            Zombie_I.sustraerTropas(obtenerNumeroAtaque());
	}
	if ("Zombie_J".equals(planetaEmisor)) {
            Zombie_J.sustraerTropas(obtenerNumeroAtaque());
	}
    }
    
    private void organizarTurnos() {
	int tope = 9;
	
	if (jugadorEnTurno == 1) {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < tope; j++) {
                    if (turnosAtaquesJugadorUno[j] > turnosAtaquesJugadorUno[j + 1]) {
                        int copia = turnosAtaquesJugadorUno[j];
                        turnosAtaquesJugadorUno[j] = turnosAtaquesJugadorUno[j + 1];
                        turnosAtaquesJugadorUno[j + 1] = copia;
                        int copia1 = numeroDeTropasJUA[j];
                        numeroDeTropasJUA[j] = numeroDeTropasJUA[j + 1];
                        numeroDeTropasJUA[j + 1] = copia1;
                        String copia2 = planetasQueAtacanJU[j];
                        planetasQueAtacanJU[j] = planetasQueAtacanJU[j + 1];
                        planetasQueAtacanJU[j + i] = copia2;
                        String copia3 = planetasAAtacarJU[j];
                        planetasAAtacarJU[j] = planetasAAtacarJU[j + 1];
                        planetasAAtacarJU[j + 1] = copia3;
                    }
                }	
                tope--;
            }
	} else {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < tope; j++) {
                    if (turnosAtaquesJugadorDos[j] > turnosAtaquesJugadorDos[j + 1]) {
                        int copia = turnosAtaquesJugadorDos[j];
                        turnosAtaquesJugadorDos[j] = turnosAtaquesJugadorDos[j + 1];
                        turnosAtaquesJugadorDos[j + 1] = copia;
                        int copia1 = numeroDeTropasJDA[j];
                        numeroDeTropasJDA[j] = numeroDeTropasJDA[j + 1];
                        numeroDeTropasJDA[j + 1] = copia1;
                        String copia2 = planetasQueAtacanJD[j];
                        planetasQueAtacanJD[j] = planetasQueAtacanJD[j + 1];
                        planetasQueAtacanJD[j + i] = copia2;
                        String copia3 = planetasAAtacarJD[j];
                        planetasAAtacarJD[j] = planetasAAtacarJD[j + 1];
                        planetasAAtacarJD[j + 1] = copia3;
                    }
                }	
                tope--;
            }
	}	
    }
    
    private void organizarTurnos1() {
        int tope = 9;
        
        if (jugadorEnTurno == 1) {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < tope; j++) {
                    if (turnosRefuerzosJugadorUno[j] > turnosRefuerzosJugadorUno[j + 1]) {
                        int copia = turnosRefuerzosJugadorUno[j];
                        turnosRefuerzosJugadorUno[j] = turnosRefuerzosJugadorUno[j + 1];
                        turnosRefuerzosJugadorUno[j + 1] = copia;
                        int copia1 = numeroDeTropasJUR[j];
                        numeroDeTropasJUR[j] = numeroDeTropasJUR[j + 1];
                        numeroDeTropasJUR[j + 1] = copia1;
                        String copia3 = planetasAReforzarJU[j];
                        planetasAReforzarJU[j] = planetasAReforzarJU[j + 1];
                        planetasAReforzarJU[j + 1] = copia3;
                    }
                }	
                tope--;
            }
        } else {
            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < tope; j++) {
                    if (turnosRefuerzosJugadorDos[j] > turnosRefuerzosJugadorDos[j + 1]) {
                        int copia = turnosRefuerzosJugadorDos[j];
                        turnosRefuerzosJugadorDos[j] = turnosRefuerzosJugadorDos[j + 1];
                        turnosRefuerzosJugadorDos[j + 1] = copia;
                        int copia1 = numeroDeTropasJDR[j];
                        numeroDeTropasJDR[j] = numeroDeTropasJDR[j + 1];
                        numeroDeTropasJDR[j + 1] = copia1;
                        String copia3 = planetasAReforzarJD[j];
                        planetasAReforzarJD[j] = planetasAReforzarJD[j + 1];
                        planetasAReforzarJD[j + 1] = copia3;
                    }
                }	
                tope--;
            }
        }
    }
    
    private int mandarNaves(String representante) {
	int flotas = 0;
	
	if ("Player_1".equals(representante)) {
            flotas = Player_1.mandarNaves();
	}
	if ("Player_2".equals(representante)) {
            flotas = Player_2.mandarNaves();
	}
        if ("Neutral_A".equals(representante)) {
            flotas = Neutral_A.mandarNaves();
	}
	if ("Neutral_B".equals(representante)) {
            flotas = Neutral_B.mandarNaves();
	}
        if ("Neutral_C".equals(representante)) {
            flotas = Neutral_C.mandarNaves();
	}
	if ("Neutral_D".equals(representante)) {
            flotas = Neutral_D.mandarNaves();
	}
        if ("Neutral_E".equals(representante)) {
            flotas = Neutral_E.mandarNaves();
	}
	if ("Neutral_F".equals(representante)) {
            flotas = Neutral_F.mandarNaves();
	}
        if ("Neutral_G".equals(representante)) {
            flotas = Neutral_G.mandarNaves();
	}
	if ("Neutral_H".equals(representante)) {
            flotas = Neutral_H.mandarNaves();
	}
        if ("Neutral_I".equals(representante)) {
            flotas = Neutral_I.mandarNaves();
	}
	if ("Neutral_J".equals(representante)) {
            flotas = Neutral_J.mandarNaves();
	}
        if ("Zombie_A".equals(representante)) {
            flotas = Zombie_A.mandarNaves();
	}
	if ("Zombie_B".equals(representante)) {
            flotas = Zombie_B.mandarNaves();
	}
        if ("Zombie_C".equals(representante)) {
            flotas = Zombie_C.mandarNaves();
	}
	if ("Zombie_D".equals(representante)) {
            flotas = Zombie_D.mandarNaves();
	}
        if ("Zombie_E".equals(representante)) {
            flotas = Zombie_E.mandarNaves();
	}
	if ("Zombie_F".equals(representante)) {
            flotas = Zombie_F.mandarNaves();
	}
        if ("Zombie_G".equals(representante)) {
            flotas = Zombie_G.mandarNaves();
	}
	if ("Zombie_H".equals(representante)) {
            flotas = Zombie_H.mandarNaves();
	}
        if ("Zombie_I".equals(representante)) {
            flotas = Zombie_I.mandarNaves();
	}
	if ("Zombie_J".equals(representante)) {
            flotas = Zombie_J.mandarNaves();
	}
	return flotas;
    }
    
    private double mandarPorcentaje(String representante) {
	double porcentaje = 0;
	
	if ("Player_1".equals(representante)) {
            porcentaje = Player_1.mandarPorcentaje();
	}
	if ("Player_2".equals(representante)) {
            porcentaje = Player_2.mandarPorcentaje();
	}
        if ("Neutral_A".equals(representante)) {
            porcentaje = Neutral_A.mandarPorcentaje();
	}
	if ("Neutral_B".equals(representante)) {
            porcentaje = Neutral_B.mandarPorcentaje();
	}
        if ("Neutral_C".equals(representante)) {
            porcentaje = Neutral_C.mandarPorcentaje();
	}
	if ("Neutral_D".equals(representante)) {
            porcentaje = Neutral_D.mandarPorcentaje();
	}
        if ("Neutral_E".equals(representante)) {
            porcentaje = Neutral_E.mandarPorcentaje();
	}
	if ("Neutral_F".equals(representante)) {
            porcentaje = Neutral_F.mandarPorcentaje();
	}
        if ("Neutral_G".equals(representante)) {
            porcentaje = Neutral_G.mandarPorcentaje();
	}
	if ("Neutral_H".equals(representante)) {
            porcentaje = Neutral_H.mandarPorcentaje();
	}
        if ("Neutral_I".equals(representante)) {
            porcentaje = Neutral_I.mandarPorcentaje();
	}
	if ("Neutral_J".equals(representante)) {
            porcentaje = Neutral_J.mandarPorcentaje();
	}
        if ("Zombie_A".equals(representante)) {
            porcentaje = Zombie_A.mandarPorcentaje();
	}
	if ("Zombie_B".equals(representante)) {
            porcentaje = Zombie_B.mandarPorcentaje();
	}
        if ("Zombie_C".equals(representante)) {
            porcentaje = Zombie_C.mandarPorcentaje();
	}
	if ("Zombie_D".equals(representante)) {
            porcentaje = Zombie_D.mandarPorcentaje();
	}
        if ("Zombie_E".equals(representante)) {
            porcentaje = Zombie_E.mandarPorcentaje();
	}
	if ("Zombie_F".equals(representante)) {
            porcentaje = Zombie_F.mandarPorcentaje();
	}
        if ("Zombie_G".equals(representante)) {
            porcentaje = Zombie_G.mandarPorcentaje();
	}
	if ("Zombie_H".equals(representante)) {
            porcentaje = Zombie_H.mandarPorcentaje();
	}
        if ("Zombie_I".equals(representante)) {
            porcentaje = Zombie_I.mandarPorcentaje();
	}
	if ("Zombie_J".equals(representante)) {
            porcentaje = Zombie_J.mandarPorcentaje();
	}
	return porcentaje;
    }
    
    private void mandarAtaque(String atacante, String defensor) {
        
        naves1 = (int) (naves1 * porcentaje1);
        naves2 = (int) (naves2 * porcentaje2);

        int navesRestantes1 = naves1 - naves2;
        int navesRestantes2 = naves2 - naves1;

        if (navesRestantes1 <= 0 && navesRestantes2 > 0) {
            JOptionPane.showMessageDialog(this,"El planeta " + atacante + " ataco al " + defensor + " pero resistio al Ataque","Informe del Ataque",JOptionPane.INFORMATION_MESSAGE);
            reordenarTurnos();
        }
        if (navesRestantes1 <= 0 && navesRestantes2 <= 0) {
            JOptionPane.showMessageDialog(this,"El planeta " + atacante + " ataco al " + defensor + " pero resistio al Ataque","Informe del Ataque",JOptionPane.INFORMATION_MESSAGE);
            reordenarTurnos();
        }
        if (navesRestantes1 > 0 && navesRestantes2 <= 0) {
            JOptionPane.showMessageDialog(this,"El planeta " + atacante + " conquisto el planeta " + defensor,"Informe del Ataque",JOptionPane.INFORMATION_MESSAGE);
            if (acceso == 0) {
                for (int i = 0; i < 10; i++) {
                    if (planetasDelJU[i] == null) {
                        planetasDelJU[i] = defensor;
                        break;
                    }
                }
                /*
                for (int j = 0; j < 10; j++) {
                    if (planetasDelJD[j].equals(defensor)) {
                        planetasDelJD[j] = null;
                        break;
                    }
                }
                */
                reordenarTurnos();
            } else {
                for (int i = 0; i < 10; i++) {
                    if (planetasDelJD[i] == null) {
                        planetasDelJD[i] = defensor;
                        break;
                    }
                }
                /*
                for (int j = 0; j < 10; j++) {
                    if (planetasDelJU[j].equals(defensor)) {
                        planetasDelJU[j] = null;
                        break;
                    }
                }
                */
                reordenarTurnos();
            }    
        }
    }
    
    private void reordenarTurnos() {
	if (jugadorEnTurno == 1) {
            for (int i = 0; i < 9; i++) {
                turnosAtaquesJugadorUno[i] = turnosAtaquesJugadorUno[i + 1];
                numeroDeTropasJUA[i] = numeroDeTropasJUA[i + 1];
                planetasQueAtacanJU[i] = planetasQueAtacanJU[i + 1];
                planetasAAtacarJU[i] = planetasAAtacarJU[i + 1];
            }
            turnosAtaquesJugadorUno[9] = 100;
            numeroDeTropasJUA[9] = 0;
            planetasQueAtacanJU[9] = null;
            planetasAAtacarJU[9] = null;
	} else {
            for (int i = 0; i < 9; i++) {
                turnosAtaquesJugadorDos[i] = turnosAtaquesJugadorDos[i + 1];
                numeroDeTropasJDA[i] = numeroDeTropasJDA[i + 1];
                planetasQueAtacanJD[i] = planetasQueAtacanJD[i + 1];
                planetasAAtacarJD[i] = planetasAAtacarJD[i + 1];
            }
            turnosAtaquesJugadorDos[9] = 100;
            numeroDeTropasJDA[9] = 0;
            planetasQueAtacanJD[9] = null;
            planetasAAtacarJD[9] = null;
	}
    }
    
    private void mandarRefuerzos(String ayuda) {
        if ("Player_1".equals(ayuda)) {
            Player_1.aumentarTropas(naves1);
        }
        if ("Player_2".equals(ayuda)) {
            Player_2.aumentarTropas(naves1);
        }
        if ("Neutral_A".equals(ayuda)) {
            Neutral_A.aumentarTropas(naves1);
        }
        if ("Neutral_B".equals(ayuda)) {
            Neutral_B.aumentarTropas(naves1);
        }
        if ("Neutral_C".equals(ayuda)) {
            Neutral_C.aumentarTropas(naves1);
        }
        if ("Neutral_D".equals(ayuda)) {
            Neutral_D.aumentarTropas(naves1);
        }
        if ("Neutral_E".equals(ayuda)) {
            Neutral_E.aumentarTropas(naves1);
        }
        if ("Neutral_F".equals(ayuda)) {
            Neutral_F.aumentarTropas(naves1);
        }
        if ("Neutral_G".equals(ayuda)) {
            Neutral_G.aumentarTropas(naves1);
        }
        if ("Neutral_H".equals(ayuda)) {
            Neutral_H.aumentarTropas(naves1);
        }
        if ("Neutral_I".equals(ayuda)) {
            Neutral_I.aumentarTropas(naves1);
        }
        if ("Neutral_J".equals(ayuda)) {
            Neutral_J.aumentarTropas(naves1);
        }
        if ("Zombie_A".equals(ayuda)) {
            Zombie_A.aumentarTropas(naves1);
        }
        if ("Zombie_B".equals(ayuda)) {
            Zombie_B.aumentarTropas(naves1);
        }
        if ("Zombie_C".equals(ayuda)) {
            Zombie_C.aumentarTropas(naves1);
        }
        if ("Zombie_D".equals(ayuda)) {
            Zombie_D.aumentarTropas(naves1);
        }
        if ("Zombie_E".equals(ayuda)) {
            Zombie_E.aumentarTropas(naves1);
        }
        if ("Zombie_F".equals(ayuda)) {
            Zombie_F.aumentarTropas(naves1);
        }
        if ("Zombie_G".equals(ayuda)) {
            Zombie_G.aumentarTropas(naves1);
        }
        if ("Zombie_H".equals(ayuda)) {
            Zombie_H.aumentarTropas(naves1);
        }
        if ("Zombie_I".equals(ayuda)) {
            Zombie_I.aumentarTropas(naves1);
        }
        if ("Zombie_J".equals(ayuda)) {
            Zombie_J.aumentarTropas(naves1);
        }
        if (jugadorEnTurno == 1) {
            JOptionPane.showMessageDialog(this,"El planeta " + planetasAReforzarJU[0] + " fue reforzado con " + naves1 + " naves","Informe de los Refuerzos",JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,"El planeta " + planetasAReforzarJD[0] + " fue reforzado con " + naves1 + " naves","Informe de los Refuerzos",JOptionPane.INFORMATION_MESSAGE);
        }
        reordenarTurnos1();
    }
    
    private void reordenarTurnos1() {
        if (jugadorEnTurno == 1) {
            for (int i = 0; i < 9; i++) {
                turnosRefuerzosJugadorUno[i] = turnosRefuerzosJugadorUno[i + 1];
                numeroDeTropasJUR[i] = numeroDeTropasJUR[i + 1];
                planetasAReforzarJU[i] = planetasAReforzarJU[i + 1];
            }
            turnosRefuerzosJugadorUno[9] = 100;
            numeroDeTropasJUR[9] = 0;
            planetasAReforzarJU[9] = null;
        } else {
            for (int i = 0; i < 9; i++) {
                turnosRefuerzosJugadorDos[i] = turnosRefuerzosJugadorDos[i + 1];
                numeroDeTropasJDR[i] = numeroDeTropasJDR[i + 1];
                planetasAReforzarJD[i] = planetasAReforzarJD[i + 1];
            }
            turnosRefuerzosJugadorDos[9] = 100;
            numeroDeTropasJDR[9] = 0;
            planetasAReforzarJD[9] = null;
        }
    }
    
    private int obtenerNumeroAtaque() {
        return (int) numeroAtaque.getValue();
    }
    
    private int obtenerNumeroRefuerzo() {
        return (int) numeroAtaque.getValue();
    }
    
    private void organizarPlanetas() {
        String nombre = null;
        int indice = 0;
        
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < anchura; j++) {
                mapa[i][j] = "Espacio";
                
                if (i == 0 && j == 0) {
                    mapa0.setText("Espacio");
                }
                if (i == 0 && j == 1) {
                    mapa1.setText("Espacio");
                }
                if (i == 0 && j == 2) {
                    mapa2.setText("Espacio");
                }
                if (i == 0 && j == 3) {
                    mapa3.setText("Espacio");
                }
                if (i == 0 && j == 4) {
                    mapa4.setText("Espacio");
                }
                if (i == 0 && j == 5) {
                    mapa5.setText("Espacio");
                }
                if (i == 0 && j == 6) {
                    mapa6.setText("Espacio");
                }
                if (i == 0 && j == 7) {
                    mapa7.setText("Espacio");
                }
                if (i == 1 && j == 0) {
                    mapa8.setText("Espacio");
                }
                if (i == 1 && j == 1) {
                    mapa9.setText("Espacio");
                }
                if (i == 1 && j == 2) {
                    mapa10.setText("Espacio");
                }
                if (i == 1 && j == 3) {
                    mapa11.setText("Espacio");
                }
                if (i == 1 && j == 4) {
                    mapa12.setText("Espacio");
                }
                if (i == 1 && j == 5) {
                    mapa13.setText("Espacio");
                }
                if (i == 1 && j == 6) {
                    mapa14.setText("Espacio");
                }
                if (i == 1 && j == 7) {
                    mapa15.setText("Espacio");
                }
                if (i == 2 && j == 0) {
                    mapa16.setText("Espacio");
                }
                if (i == 2 && j == 1) {
                    mapa17.setText("Espacio");
                }
                if (i == 2 && j == 2) {
                    mapa18.setText("Espacio");
                }
                if (i == 2 && j == 3) {
                    mapa19.setText("Espacio");
                }
                if (i == 2 && j == 4) {
                    mapa20.setText("Espacio");
                }
                if (i == 2 && j == 5) {
                    mapa21.setText("Espacio");
                }
                if (i == 2 && j == 6) {
                    mapa22.setText("Espacio");
                }
                if (i == 2 && j == 7) {
                    mapa23.setText("Espacio");
                }
                if (i == 3 && j == 0) {
                    mapa24.setText("Espacio");
                }
                if (i == 3 && j == 1) {
                    mapa25.setText("Espacio");
                }
                if (i == 3 && j == 2) {
                    mapa26.setText("Espacio");
                }
                if (i == 3 && j == 3) {
                    mapa27.setText("Espacio");
                }
                if (i == 3 && j == 4) {
                    mapa28.setText("Espacio");
                }
                if (i == 3 && j == 5) {
                    mapa29.setText("Espacio");
                }
                if (i == 3 && j == 6) {
                    mapa30.setText("Espacio");
                }
                if (i == 3 && j == 7) {
                    mapa31.setText("Espacio");
                }
                if (i == 4 && j == 0) {
                    mapa32.setText("Espacio");
                }
                if (i == 4 && j == 1) {
                    mapa33.setText("Espacio");
                }
                if (i == 4 && j == 2) {
                    mapa34.setText("Espacio");
                }
                if (i == 4 && j == 3) {
                    mapa35.setText("Espacio");
                }
                if (i == 4 && j == 4) {
                    mapa36.setText("Espacio");
                }
                if (i == 4 && j == 5) {
                    mapa37.setText("Espacio");
                }
                if (i == 4 && j == 6) {
                    mapa38.setText("Espacio");
                }
                if (i == 4 && j == 7) {
                    mapa39.setText("Espacio");
                }
                if (i == 5 && j == 0) {
                    mapa40.setText("Espacio");
                }
                if (i == 5 && j == 1) {
                    mapa41.setText("Espacio");
                }
                if (i == 5 && j == 2) {
                    mapa42.setText("Espacio");
                }
                if (i == 5 && j == 3) {
                    mapa43.setText("Espacio");
                }
                if (i == 5 && j == 4) {
                    mapa44.setText("Espacio");
                }
                if (i == 5 && j == 5) {
                    mapa45.setText("Espacio");
                }
                if (i == 5 && j == 6) {
                    mapa46.setText("Espacio");
                }
                if (i == 5 && j == 7) {
                    mapa47.setText("Espacio");
                }
            }
        }
        
        while (indice < 2) {
            int y = (int) (Math.random()*altura);
            int x = (int) (Math.random()*anchura);

            if (indice == 0) {
                nombre = "Player_1";
            } else {
                nombre = "Player_2";
            }
            if ("Espacio".equals(mapa[y][x])) {
                mapa[y][x] = nombre;
                asignarPlanetas(y,x,nombre);
                indice++;
            }
        }

        indice = 0;
        while (indice < neutrales) {
            int y = (int) (Math.random()*altura);
            int x = (int) (Math.random()*anchura);

            if (indice == 0) {
                nombre = "Neutral_A";
            }
            if (indice == 1) {
                nombre = "Neutral_B";
            }
            if (indice == 2) {
                nombre = "Neutral_C";
            }
            if (indice == 3) {
                nombre = "Neutral_D";
            }
            if (indice == 4) {
                nombre = "Neutral_E";
            }
            if (indice == 5) {
                nombre = "Neutral_F";
            }
            if ("Espacio".equals(mapa[y][x])) {
                mapa[y][x] = nombre;
                asignarPlanetas(y,x,nombre);
                indice++;
            }
        }

        indice = 0;
        while (indice < zombies) {
            int y = (int) (Math.random()*altura);
            int x = (int) (Math.random()*anchura);

            if (indice == 0) {
                nombre = "Zombie_A";
            }
            if (indice == 1) {
                nombre = "Zombie_B";
            }
            if (indice == 2) {
                nombre = "Zombie_C";
            }
            if (indice == 3) {
                nombre = "Zombie_D";
            }
            if (indice == 4) {
                nombre = "Zombie_E";
            }
            if (indice == 5) {
                nombre = "Zombie_F";
            }
            if ("Espacio".equals(mapa[y][x])) {
                mapa[y][x] = nombre;
                asignarPlanetas(y,x,nombre);
                indice++;
            }
        } 	
    }	
	
    private void asignarPlanetas(int i, int j, String nombre) {
        if (i == 0 && j == 0) {
            mapa0.setText(nombre);
        }
        if (i == 0 && j == 1) {
            mapa1.setText(nombre);
        }
        if (i == 0 && j == 2) {
            mapa2.setText(nombre);
        }
        if (i == 0 && j == 3) {
            mapa3.setText(nombre);
        }
        if (i == 0 && j == 4) {
            mapa4.setText(nombre);
        }
        if (i == 0 && j == 5) {
            mapa5.setText(nombre);
        }
        if (i == 0 && j == 6) {
            mapa6.setText(nombre);
        }
        if (i == 0 && j == 7) {
            mapa7.setText(nombre);
        }
        if (i == 1 && j == 0) {
            mapa8.setText(nombre);
        }
        if (i == 1 && j == 1) {
            mapa9.setText(nombre);
        }
        if (i == 1 && j == 2) {
            mapa10.setText(nombre);
        }
        if (i == 1 && j == 3) {
            mapa11.setText(nombre);
        }
        if (i == 1 && j == 4) {
            mapa12.setText(nombre);
        }
        if (i == 1 && j == 5) {
            mapa13.setText(nombre);
        }
        if (i == 1 && j == 6) {
            mapa14.setText(nombre);
        }
        if (i == 1 && j == 7) {
            mapa15.setText(nombre);
        }
        if (i == 2 && j == 0) {
            mapa16.setText(nombre);
        }
        if (i == 2 && j == 1) {
            mapa17.setText(nombre);
        }
        if (i == 2 && j == 2) {
            mapa18.setText(nombre);
        }
        if (i == 2 && j == 3) {
            mapa19.setText(nombre);
        }
        if (i == 2 && j == 4) {
            mapa20.setText(nombre);
        }
        if (i == 2 && j == 5) {
            mapa21.setText(nombre);
        }
        if (i == 2 && j == 6) {
            mapa22.setText(nombre);
        }
        if (i == 2 && j == 7) {
            mapa23.setText(nombre);
        }
        if (i == 3 && j == 0) {
            mapa24.setText(nombre);
        }
        if (i == 3 && j == 1) {
            mapa25.setText(nombre);
        }
        if (i == 3 && j == 2) {
            mapa26.setText(nombre);
        }
        if (i == 3 && j == 3) {
            mapa27.setText(nombre);
        }
        if (i == 3 && j == 4) {
            mapa28.setText(nombre);
        }
        if (i == 3 && j == 5) {
            mapa29.setText(nombre);
        }
        if (i == 3 && j == 6) {
            mapa30.setText(nombre);
        }
        if (i == 3 && j == 7) {
            mapa31.setText(nombre);
        }
        if (i == 4 && j == 0) {
            mapa32.setText(nombre);
        }
        if (i == 4 && j == 1) {
            mapa33.setText(nombre);
        }
        if (i == 4 && j == 2) {
            mapa34.setText(nombre);
        }
        if (i == 4 && j == 3) {
            mapa35.setText(nombre);
        }
        if (i == 4 && j == 4) {
            mapa36.setText(nombre);
        }
        if (i == 4 && j == 5) {
            mapa37.setText(nombre);
        }
        if (i == 4 && j == 6) {
            mapa38.setText(nombre);
        }
        if (i == 4 && j == 7) {
            mapa39.setText(nombre);
        }
        if (i == 5 && j == 0) {
            mapa40.setText(nombre);
        }
        if (i == 5 && j == 1) {
            mapa41.setText(nombre);
        }
        if (i == 5 && j == 2) {
            mapa42.setText(nombre);
        }
        if (i == 5 && j == 3) {
            mapa43.setText(nombre);
        }
        if (i == 5 && j == 4) {
            mapa44.setText(nombre);
        }
        if (i == 5 && j == 5) {
            mapa45.setText(nombre);
        }
        if (i == 5 && j == 6) {
            mapa46.setText(nombre);
        }
        if (i == 5 && j == 7) {
            mapa47.setText(nombre);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Mensajes;
    private javax.swing.JButton confirmarCoordenadas;
    private javax.swing.JButton enviarA;
    private javax.swing.JButton enviarR;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel letreroDelJugEnTurno;
    private javax.swing.JLabel linea1;
    private javax.swing.JLabel linea2;
    private javax.swing.JLabel linea3;
    private javax.swing.JLabel linea4;
    private javax.swing.JLabel linea5;
    private javax.swing.JLabel mapa0;
    private javax.swing.JLabel mapa1;
    private javax.swing.JLabel mapa10;
    private javax.swing.JLabel mapa11;
    private javax.swing.JLabel mapa12;
    private javax.swing.JLabel mapa13;
    private javax.swing.JLabel mapa14;
    private javax.swing.JLabel mapa15;
    private javax.swing.JLabel mapa16;
    private javax.swing.JLabel mapa17;
    private javax.swing.JLabel mapa18;
    private javax.swing.JLabel mapa19;
    private javax.swing.JLabel mapa2;
    private javax.swing.JLabel mapa20;
    private javax.swing.JLabel mapa21;
    private javax.swing.JLabel mapa22;
    private javax.swing.JLabel mapa23;
    private javax.swing.JLabel mapa24;
    private javax.swing.JLabel mapa25;
    private javax.swing.JLabel mapa26;
    private javax.swing.JLabel mapa27;
    private javax.swing.JLabel mapa28;
    private javax.swing.JLabel mapa29;
    private javax.swing.JLabel mapa3;
    private javax.swing.JLabel mapa30;
    private javax.swing.JLabel mapa31;
    private javax.swing.JLabel mapa32;
    private javax.swing.JLabel mapa33;
    private javax.swing.JLabel mapa34;
    private javax.swing.JLabel mapa35;
    private javax.swing.JLabel mapa36;
    private javax.swing.JLabel mapa37;
    private javax.swing.JLabel mapa38;
    private javax.swing.JLabel mapa39;
    private javax.swing.JLabel mapa4;
    private javax.swing.JLabel mapa40;
    private javax.swing.JLabel mapa41;
    private javax.swing.JLabel mapa42;
    private javax.swing.JLabel mapa43;
    private javax.swing.JLabel mapa44;
    private javax.swing.JLabel mapa45;
    private javax.swing.JLabel mapa46;
    private javax.swing.JLabel mapa47;
    private javax.swing.JLabel mapa5;
    private javax.swing.JLabel mapa6;
    private javax.swing.JLabel mapa7;
    private javax.swing.JLabel mapa8;
    private javax.swing.JLabel mapa9;
    private javax.swing.JSpinner numeroAtaque;
    private javax.swing.JLabel numeroDeTurno;
    private javax.swing.JSpinner numeroRefuerzo;
    private javax.swing.JButton terminarTurno;
    private javax.swing.JButton volverASeleccionar;
    // End of variables declaration//GEN-END:variables
}
