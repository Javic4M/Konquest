/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.konquest.planetas;

/**
 *
 * @author DELL
 */
public class Zombie_D extends Planeta {
    
    public Zombie_D() {
        naves = 25;
        porcentaje = 0.35;
    }
    
    public boolean compararTropas(int comparacion) {
        boolean permitir = false;
        
        if (comparacion <= naves) {
            permitir = true;
        }
        return permitir;
    }
    
    public void sustraerTropas(int quitar) {
        naves = naves - quitar;
    }
    
    public int mandarNaves() {
        return naves;
    }
    
    public double mandarPorcentaje() {
        return porcentaje;
    }
    
    public void aumentarTropas(int aumento) {
        naves = naves + aumento;
    }
}
