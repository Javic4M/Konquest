/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.konquest.planetas;

/**
 *
 * @author DELL
 */
public class Planeta {
    int naves;
    double porcentaje;
    
    public Planeta() {
        naves = 10;
        porcentaje = 0.75;
    }
    
    protected boolean compararTropas(int comparacion) {
        boolean permitir = false;
        
        if (comparacion <= naves) {
            permitir = true;
        }
        return permitir;
    }
    
    private void sustraerTropas(int quitar) {
        naves = naves - quitar;
    }
    
    private double mandarNaves() {
        return naves;
    }
    
    private double mandarPorcentaje() {
        return porcentaje;
    }
    
    private void aumentarTropas() {
        
    }
}
